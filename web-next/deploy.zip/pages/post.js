import Layout from "../components/Layout"

const Post = () => {
    return (
        <Layout>
            <h1>Hi this is a test post topic</h1>

        </Layout>
    );
}
export default Post;